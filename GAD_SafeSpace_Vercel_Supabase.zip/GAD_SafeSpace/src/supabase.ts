import {createClient} from '@supabase/supabase-js';
export const supabaseUrl='https://hamxrxuatenyqiqbxtrx.supabase.co';
export const publishableKey='sb_publishable_5Z54X3tHMsQA-eXyQLcrJg_npIq2R57';
export const supabase=createClient(supabaseUrl,publishableKey);
