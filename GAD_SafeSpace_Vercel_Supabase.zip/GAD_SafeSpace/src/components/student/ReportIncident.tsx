import { useState, useRef } from "react";
import { api, upload } from "../../api";
import type { NavigateFn } from "../../App";

interface Props {
  onNavigate: NavigateFn;
}

type Step =
  | "safety"
  | "emergency"
  | "concern"
  | "details"
  | "people"
  | "evidence"
  | "confidentiality"
  | "contact"
  | "review"
  | "done";

const STEPS: Step[] = ["safety", "concern", "details", "people", "evidence", "confidentiality", "contact", "review"];
const STEP_LABELS = ["Safety", "Concern", "Details", "People", "Evidence", "Privacy", "Contact", "Review"];

const concernTypes = [
  { id: "sexual-harassment", label: "Sexual Harassment", icon: "⚠️" },
  { id: "bullying", label: "Bullying / Cyberbullying", icon: "🔇" },
  { id: "gbv", label: "Gender-Based Violence", icon: "🛑" },
  { id: "discrimination", label: "Discrimination", icon: "⚖️" },
  { id: "stalking", label: "Stalking / Unwanted Attention", icon: "👁" },
  { id: "inappropriate-conduct", label: "Inappropriate Conduct", icon: "🚫" },
  { id: "other", label: "Other Concern", icon: "📋" },
];

const locations = [
  "Classroom", "Library", "Canteen / Cafeteria", "Comfort Room", "Laboratory",
  "Dormitory / Residence Hall", "Online / Social Media", "Sports Area",
  "Administration Building", "North Building Corridor", "Parking Area", "Other",
];

const confidentialityOptions = [
  {
    id: "identified",
    label: "I want to identify myself and be contacted",
    desc: "Your name will be on file with GAD. Officers will reach out to you.",
    icon: "👤",
  },
  {
    id: "confidential",
    label: "Keep my identity confidential from people involved",
    desc: "Your identity is available to the GAD Director. Triage staff cannot view case details.",
    icon: "🔒",
  },
  {
    id: "anonymous",
    label: "Omit my name from the case summary",
    desc: "Your account remains linked for tracking and audit. This is not an anonymous submission.",
    icon: "🕶️",
  },
  {
    id: "advice",
    label: "I only want advice — not a formal complaint",
    desc: "This saves a request marked as advice for the director to review. You can also request a consultation.",
    icon: "💬",
  },
];

const contactOptions = [
  { id: "email", label: "Email", sub: "Your signed-in account email" },
  { id: "phone", label: "Phone Call", sub: "Include a safe contact number in your description" },
  { id: "message", label: "In-System Message", sub: "Private GAD SafeSpace message" },
  { id: "none", label: "Do not contact me yet", sub: "I will check status myself" },
];

function riskLevel(form: FormData): { level: string; color: string; bg: string } {
  const isViolent = form.concern === "gbv" || form.concern === "sexual-harassment";
  const isAuthority = form.reportedRole === "faculty" || form.reportedRole === "admin";
  const isRepeated = form.repeated;
  if (isViolent) return { level: "High", color: "text-red-700", bg: "bg-red-50 border-red-200" };
  if (isAuthority && isRepeated) return { level: "High", color: "text-red-700", bg: "bg-red-50 border-red-200" };
  if (isAuthority || isRepeated) return { level: "Moderate", color: "text-amber-700", bg: "bg-amber-50 border-amber-200" };
  return { level: "Low", color: "text-emerald-700", bg: "bg-emerald-50 border-emerald-200" };
}

interface FormData {
  concern: string;
  incidentDate: string;
  incidentTime: string;
  location: string;
  description: string;
  reportedName: string;
  reportedRole: string;
  witnesses: string;
  repeated: boolean;
  confidentiality: string;
  contact: string;
}

const defaultForm: FormData = {
  concern: "",
  incidentDate: "",
  incidentTime: "",
  location: "",
  description: "",
  reportedName: "",
  reportedRole: "student",
  witnesses: "",
  repeated: false,
  confidentiality: "",
  contact: "email",
};

export default function ReportIncident({ onNavigate }: Props) {
  const [step, setStep] = useState<Step>("safety");
  const [form, setForm] = useState<FormData>(defaultForm);
  const [refNumber, setRefNumber] = useState("");
  const [files, setFiles] = useState<File[]>([]);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const pending = useRef(false);
  const savedId = useRef("");
  const sent = useRef(new Set<File>());
  const submit = async () => {
    if (pending.current) return;
    pending.current=true;setBusy(true);setError("");
    try {
      if (!savedId.current) { const result=await api({action:"report",data:form});savedId.current=result.id;setRefNumber(result.id); }
      for(const file of files) if(!sent.current.has(file)){await upload(savedId.current,file);sent.current.add(file)}
      setStep("done");
    } catch(e:any){setError((savedId.current ? "Report saved as "+savedId.current+". Evidence upload incomplete; retry to finish. " : "")+e.message)}
    finally {pending.current=false;setBusy(false)}
  };

  const currentIndex = STEPS.indexOf(step);

  const next = () => {
    setError("");
    if(step==="concern"&&!form.concern){setError("Select a concern.");return}
    if(step==="details"&&(!form.incidentDate||!form.location||form.description.trim().length<20)){setError("Enter a date, location, and description of at least 20 characters.");return}
    if(step==="details"&&form.incidentDate>new Date().toISOString().slice(0,10)){setError("Incident date cannot be in the future.");return}
    const i = STEPS.indexOf(step);
    if (i < STEPS.length - 1) setStep(STEPS[i + 1]);
    else void submit();
  };
  const back = () => {
    const i = STEPS.indexOf(step);
    if (i > 0) setStep(STEPS[i - 1]);
  };

  const update = <K extends keyof FormData>(key: K, val: FormData[K]) =>
    setForm((f) => ({ ...f, [key]: val }));

  if (step === "safety") {
    return (
      <div className="max-w-xl mx-auto px-6 py-10">
        <div className="text-center mb-8">
          <div className="w-16 h-16 rounded-full bg-rose-100 flex items-center justify-center mx-auto mb-4 text-3xl">
            🛡️
          </div>
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Before we begin</h1>
          <p className="text-gray-500 text-sm">Your safety is our first priority.</p>
        </div>

        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 mb-6">
          <h2 className="font-bold text-gray-800 text-lg mb-4 text-center">
            Are you in immediate danger right now?
          </h2>
          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={() => setStep("emergency")}
              className="flex flex-col items-center justify-center gap-2 py-6 rounded-xl bg-red-50 border-2 border-red-200 hover:bg-red-100 transition-colors"
            >
              <span className="text-3xl">🆘</span>
              <span className="font-bold text-red-700 text-sm">Yes — I need help now</span>
            </button>
            <button
              onClick={() => setStep("concern")}
              className="flex flex-col items-center justify-center gap-2 py-6 rounded-xl bg-emerald-50 border-2 border-emerald-200 hover:bg-emerald-100 transition-colors"
            >
              <span className="text-3xl">✅</span>
              <span className="font-bold text-emerald-700 text-sm">No — I am safe now</span>
            </button>
          </div>
        </div>

        <div className="text-center">
          <button
            onClick={() => onNavigate("dashboard")}
            className="text-sm text-gray-400 hover:text-gray-600"
          >
            ← Return to Dashboard
          </button>
        </div>
      </div>
    );
  }

  if (step === "emergency") {
    return (
      <div className="max-w-xl mx-auto px-6 py-10">
        <div className="bg-red-600 rounded-2xl p-6 text-white text-center mb-6">
          <p className="text-2xl mb-2">⚠️</p>
          <h1 className="font-bold text-xl mb-2">Call for help immediately</h1>
          <p className="text-red-200 text-sm">This system cannot respond in real time. Please seek in-person help now.</p>
        </div>
        <div className="grid grid-cols-1 gap-3 mb-6">
          {[
            
            { label: "National Emergency", number: "911" },
            
          ].map((c) => (
            <div key={c.label} className="bg-white border border-red-100 rounded-xl p-4 flex items-center justify-between">
              <span className="font-medium text-gray-700 text-sm">{c.label}</span>
              <span className="font-bold text-red-600">{c.number}</span>
            </div>
          ))}
        </div>
        <button
          onClick={() => setStep("concern")}
          className="w-full bg-indigo-700 hover:bg-indigo-800 text-white font-semibold py-3 rounded-xl text-sm transition-colors"
        >
          I understand — continue with report
        </button>
        <div className="text-center mt-4">
          <button onClick={() => onNavigate("dashboard")} className="text-sm text-gray-400 hover:text-gray-600">
            ← Return to Dashboard
          </button>
        </div>
      </div>
    );
  }

  if (step === "done") {
    return (
      <div className="max-w-xl mx-auto px-6 py-10">
        <div className="text-center mb-8">
          <div className="w-20 h-20 rounded-full bg-emerald-100 flex items-center justify-center mx-auto mb-4 text-4xl">
            ✅
          </div>
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Report Submitted</h1>
          <p className="text-gray-500 text-sm">Thank you for trusting us with your report.</p>
        </div>

        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 mb-6">
          <div className="text-center mb-4">
            <p className="text-gray-500 text-xs uppercase tracking-widest mb-1">Your Reference Number</p>
            <p className="font-mono font-bold text-2xl text-indigo-700">{refNumber}</p>
            <p className="text-gray-400 text-xs mt-1">Save this number to track your report</p>
          </div>
          <div className="border-t border-gray-50 pt-4 space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-gray-500">Mode</span>
              <span className="font-medium text-gray-800 capitalize">
                {confidentialityOptions.find((o) => o.id === form.confidentiality)?.label.split("—")[0].trim() || "Confidential"}
              </span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-500">Estimated response</span>
              <span className="font-medium text-gray-800">Awaiting office review</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-500">Submitted</span>
              <span className="font-medium text-gray-800">{new Date().toLocaleDateString("en-PH")}</span>
            </div>
          </div>
        </div>

        <div className="bg-indigo-50 border border-indigo-100 rounded-xl p-4 mb-6">
          <p className="font-semibold text-indigo-800 text-sm mb-3">What happens next:</p>
          <ol className="space-y-2">
            {[
              "Your report is now in the GAD review queue",
              "The office can update the status after reviewing your concern",
              "Check secure messages for replies from the GAD Director",
              "You can track your report status at any time",
            ].map((s, i) => (
              <li key={i} className="flex gap-2 text-sm text-indigo-700">
                <span className="font-bold">{i + 1}.</span>
                <span>{s}</span>
              </li>
            ))}
          </ol>
        </div>

        <div className="flex gap-3">
          <button
            onClick={() => onNavigate("tracking")}
            className="flex-1 bg-indigo-700 hover:bg-indigo-800 text-white font-semibold py-3 rounded-xl text-sm transition-colors"
          >
            Track My Report
          </button>
          <button
            onClick={() => onNavigate("dashboard")}
            className="flex-1 bg-white hover:bg-gray-50 text-gray-700 font-semibold py-3 rounded-xl text-sm border border-gray-200 transition-colors"
          >
            Return to Dashboard
          </button>
        </div>
      </div>
    );
  }

  const risk = riskLevel(form);

  return (
    <div className="max-w-2xl mx-auto px-6 py-8">
      {/* Progress */}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-3">
          <h1 className="text-xl font-bold text-gray-900">Report an Incident</h1>
          <span className="text-sm text-gray-400">
            Step {currentIndex} of {STEPS.length - 1}
          </span>
        </div>
        <div className="flex gap-1">
          {STEPS.slice(1).map((s, i) => (
            <div
              key={s}
              className={`h-1.5 flex-1 rounded-full transition-all ${
                i < currentIndex ? "bg-indigo-600" : i === currentIndex - 1 ? "bg-indigo-400" : "bg-gray-200"
              }`}
            />
          ))}
        </div>
        <p className="text-xs text-indigo-600 font-medium mt-2">{STEP_LABELS[currentIndex] ?? ""}</p>
      </div>

      {/* Step: Concern */}
      {step === "concern" && (
        <div>
          <h2 className="text-lg font-bold text-gray-800 mb-2">What type of concern are you reporting?</h2>
          <p className="text-gray-500 text-sm mb-6">Select the category that best describes the incident.</p>
          <div className="grid grid-cols-1 gap-2">
            {concernTypes.map((c) => (
              <button
                key={c.id}
                onClick={() => update("concern", c.id)}
                className={`flex items-center gap-4 px-5 py-4 rounded-xl border-2 text-left transition-all ${
                  form.concern === c.id
                    ? "border-indigo-500 bg-indigo-50"
                    : "border-gray-200 bg-white hover:border-indigo-200 hover:bg-indigo-50/50"
                }`}
              >
                <span className="text-2xl">{c.icon}</span>
                <span className="font-medium text-gray-800">{c.label}</span>
                {form.concern === c.id && (
                  <span className="ml-auto text-indigo-600">✓</span>
                )}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Step: Details */}
      {step === "details" && (
        <div>
          <h2 className="text-lg font-bold text-gray-800 mb-2">Tell us what happened</h2>
          <p className="text-gray-500 text-sm mb-6">Provide as much detail as you are comfortable sharing.</p>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">Date of Incident</label>
                <input
                  type="date" aria-label="Date of incident"
                  onInput={(e) => update("incidentDate", e.currentTarget.value)}
                  value={form.incidentDate}
                  onChange={(e) => update("incidentDate", e.target.value)}
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">Approximate Time</label>
                <input
                  type="time" aria-label="Approximate time"
                  onInput={(e) => update("incidentTime", e.currentTarget.value)}
                  value={form.incidentTime}
                  onChange={(e) => update("incidentTime", e.target.value)}
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">Location / Campus Area</label>
              <select aria-label="Location"
                value={form.location}
                onChange={(e) => update("location", e.target.value)}
                className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="">Select a location</option>
                {locations.map((l) => (
                  <option key={l} value={l}>{l}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">Description</label>
              <textarea
                rows={5} aria-label="Incident description"
                value={form.description}
                onChange={(e) => update("description", e.target.value)}
                placeholder="Describe what happened in your own words. Include any relevant context..."
                className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none"
              />
            </div>
            <div>
              <label className="flex items-center gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={form.repeated}
                  onChange={(e) => update("repeated", e.target.checked)}
                  className="w-4 h-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                />
                <span className="text-sm text-gray-700">This has happened more than once</span>
              </label>
            </div>
          </div>
        </div>
      )}

      {/* Step: People */}
      {step === "people" && (
        <div>
          <h2 className="text-lg font-bold text-gray-800 mb-2">People involved</h2>
          <p className="text-gray-500 text-sm mb-6">
            You may use descriptions if you do not know names. All information is confidential.
          </p>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">
                Name or description of the person being reported
              </label>
              <input
                type="text"
                value={form.reportedName}
                onChange={(e) => update("reportedName", e.target.value)}
                placeholder="e.g., 'Prof. J. Cruz' or 'male student wearing blue shirt'"
                className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">Their role in the school</label>
              <div className="grid grid-cols-3 gap-2">
                {["student", "faculty", "admin", "staff", "visitor", "unknown"].map((r) => (
                  <button
                    key={r}
                    onClick={() => update("reportedRole", r)}
                    className={`py-2.5 rounded-xl border-2 text-sm font-medium capitalize transition-all ${
                      form.reportedRole === r
                        ? "border-indigo-500 bg-indigo-50 text-indigo-700"
                        : "border-gray-200 bg-white text-gray-600 hover:border-indigo-200"
                    }`}
                  >
                    {r}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">
                Witnesses (optional)
              </label>
              <input
                type="text"
                value={form.witnesses}
                onChange={(e) => update("witnesses", e.target.value)}
                placeholder="Names or descriptions of anyone who may have witnessed the incident"
                className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>
        </div>
      )}

      {error && <p role="alert" className="mb-4 p-4 rounded-xl bg-red-50 text-red-700">{error}</p>}
      {busy && <p role="status">Saving your report and evidence…</p>}
      {/* Step: Evidence */}
      {step === "evidence" && (
        <div>
          <h2 className="text-lg font-bold text-gray-800 mb-2">Supporting Evidence</h2>
          <p className="text-gray-500 text-sm mb-6">
            Upload any relevant files — screenshots, photos, documents, or audio recordings. This step is optional.
          </p>
          <label className="block border-2 border-dashed border-gray-300 rounded-2xl p-8 text-center bg-white">
            <span className="block font-semibold mb-3">Choose supporting files</span>
            <input type="file" multiple accept="image/png,image/jpeg,application/pdf,audio/mpeg,video/mp4" onChange={e=>{const chosen=Array.from(e.target.files||[]);if(chosen.length>5||chosen.some(f=>f.size>10*1024*1024)){setError("Choose up to five files, each no larger than 10 MB.");e.target.value="";return}setFiles(chosen);setError("")}}/>
            <span className="block text-xs text-gray-500 mt-3">PNG, JPG, PDF, MP3, MP4 · Up to 5 files · 10 MB each</span>
          </label>
          {files.map((file,i)=><div key={i} className="flex justify-between p-3 bg-white rounded-xl mt-2"><span>{file.name}</span><button onClick={()=>setFiles(files.filter((_,n)=>n!==i))}>Remove</button></div>)}
          <p className="text-xs text-gray-500 mt-4">Files are available only to you and the GAD Director through protected downloads.</p>
        </div>
      )}

      {/* Step: Confidentiality */}
      {step === "confidentiality" && (
        <div>
          <h2 className="text-lg font-bold text-gray-800 mb-2">How would you like this report handled?</h2>
          <p className="text-gray-500 text-sm mb-6">
            Choose the option that feels right for you. You can change this later by contacting the GAD Office.
          </p>
          <div className="space-y-3">
            {confidentialityOptions.map((opt) => (
              <button
                key={opt.id}
                onClick={() => update("confidentiality", opt.id)}
                className={`w-full flex items-start gap-4 px-5 py-4 rounded-xl border-2 text-left transition-all ${
                  form.confidentiality === opt.id
                    ? "border-indigo-500 bg-indigo-50"
                    : "border-gray-200 bg-white hover:border-indigo-200"
                }`}
              >
                <span className="text-2xl flex-shrink-0 mt-0.5">{opt.icon}</span>
                <div>
                  <p className="font-semibold text-gray-800 text-sm">{opt.label}</p>
                  <p className="text-gray-500 text-xs mt-1 leading-relaxed">{opt.desc}</p>
                </div>
                {form.confidentiality === opt.id && (
                  <span className="ml-auto flex-shrink-0 text-indigo-600">✓</span>
                )}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Step: Contact */}
      {step === "contact" && form.confidentiality !== "anonymous" && (
        <div>
          <h2 className="text-lg font-bold text-gray-800 mb-2">How should we contact you?</h2>
          <p className="text-gray-500 text-sm mb-6">
            Select your preferred method of contact from the GAD Office.
          </p>
          <div className="space-y-3">
            {contactOptions.map((opt) => (
              <button
                key={opt.id}
                onClick={() => update("contact", opt.id)}
                className={`w-full flex items-center gap-4 px-5 py-4 rounded-xl border-2 text-left transition-all ${
                  form.contact === opt.id
                    ? "border-indigo-500 bg-indigo-50"
                    : "border-gray-200 bg-white hover:border-indigo-200"
                }`}
              >
                <div className="flex-1">
                  <p className="font-semibold text-gray-800 text-sm">{opt.label}</p>
                  <p className="text-gray-500 text-xs mt-0.5">{opt.sub}</p>
                </div>
                {form.contact === opt.id && <span className="text-indigo-600">✓</span>}
              </button>
            ))}
          </div>
        </div>
      )}

      {step === "contact" && form.confidentiality === "anonymous" && (
        <div>
          <h2 className="text-lg font-bold text-gray-800 mb-2">Contact preference</h2>
          <div className="bg-amber-50 border border-amber-200 rounded-xl p-5">
            <p className="font-semibold text-amber-800 text-sm mb-2">Your name will be omitted from the case summary</p>
            <p className="text-amber-700 text-sm">
              Your account remains linked for tracking and audit. Sign in to view updates and secure messages. This is not anonymous reporting.
            </p>
          </div>
        </div>
      )}

      {/* Step: Review */}
      {step === "review" && (
        <div>
          <h2 className="text-lg font-bold text-gray-800 mb-2">Review your report</h2>
          <p className="text-gray-500 text-sm mb-6">
            Please review the information below before submitting.
          </p>

          {/* Risk assessment */}
          <div className={`${risk.bg} border rounded-xl p-4 mb-6`}>
            <div className="flex items-center gap-2">
              <span className="text-lg">🚦</span>
              <div>
                <p className="font-semibold text-sm text-gray-800">
                  Preliminary Risk Level:{" "}
                  <span className={risk.color}>{risk.level}</span>
                </p>
                <div className="bg-white border border-gray-100 rounded-xl p-4 my-5"><h3 className="font-semibold text-sm mb-2">Incident description</h3><p className="text-sm text-gray-600 whitespace-pre-wrap">{form.description}</p><p className="text-xs text-gray-500 mt-3">Evidence: {files.length ? files.map(f=>f.name).join(", ") : "No files selected"}</p></div>
          <p className="text-xs text-gray-500 mt-0.5">
                  A GAD officer will conduct a full assessment upon receipt.
                </p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm divide-y divide-gray-50 mb-6">
            {[
              {
                label: "Concern Type",
                value: concernTypes.find((c) => c.id === form.concern)?.label || "Not specified",
              },
              { label: "Date of Incident", value: form.incidentDate || "Not specified" },
              { label: "Location", value: form.location || "Not specified" },
              { label: "Reported Person", value: form.reportedName || "Not specified" },
              { label: "Their Role", value: form.reportedRole },
              { label: "Repeated Incident", value: form.repeated ? "Yes" : "No" },
              {
                label: "Reporting Mode",
                value: confidentialityOptions.find((o) => o.id === form.confidentiality)?.label || "Not selected",
              },
              {
                label: "Contact Preference",
                value: contactOptions.find((o) => o.id === form.contact)?.label || "Not specified",
              },
            ].map((item) => (
              <div key={item.label} className="flex justify-between items-start px-5 py-3 gap-4">
                <span className="text-gray-500 text-sm flex-shrink-0">{item.label}</span>
                <span className="text-gray-800 text-sm font-medium text-right">{item.value}</span>
              </div>
            ))}
          </div>

          <div className="bg-indigo-50 border border-indigo-100 rounded-xl p-4 text-sm text-indigo-700">
            By submitting, you confirm that the information above is accurate to the best of your knowledge. Your report will be saved for review by the GAD Office. This system does not dispatch emergency responders.
          </div>
        </div>
      )}

      {/* Navigation buttons */}
      <div className="flex gap-3 mt-8">
        <button
          onClick={back}
          className="flex-shrink-0 bg-white hover:bg-gray-50 text-gray-600 font-semibold py-3 px-6 rounded-xl text-sm border border-gray-200 transition-colors"
        >
          ← Back
        </button>
        <button
          onClick={step === "review" ? submit : next}
          disabled={busy ||
            (step === "concern" && !form.concern) ||
            (step === "confidentiality" && !form.confidentiality)
          }
          className="flex-1 bg-indigo-700 hover:bg-indigo-800 disabled:opacity-40 disabled:cursor-not-allowed text-white font-semibold py-3 rounded-xl text-sm transition-colors"
        >
          {step === "review" ? "Submit Report" : "Continue →"}
        </button>
      </div>
    </div>
  );
}
