import React from "react";
import type { NavigateFn } from "../App";

interface Props {
  displayName?: string;
  role: "student" | "coordinator" | "director" | "admin";
  currentView: string;
  onNavigate: NavigateFn;
  onLogout: () => void;
}

// ── Icons ──────────────────────────────────────────────────────────────────
const I = {
  Home: () => <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" /></svg>,
  Alert: () => <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" /></svg>,
  File: () => <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>,
  List: () => <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" /></svg>,
  Cal: () => <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>,
  Book: () => <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" /></svg>,
  Chat: () => <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" /></svg>,
  Bell: () => <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" /></svg>,
  Chart: () => <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" /></svg>,
  Star: () => <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" /></svg>,
  Audit: () => <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" /></svg>,
  Users: () => <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z" /></svg>,
  Cog: () => <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /></svg>,
  Shield: () => <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" /></svg>,
  Report: () => <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>,
  Logout: () => <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" /></svg>,
};

// ── Nav definitions ────────────────────────────────────────────────────────
type NavItem = { id: string; label: string; Icon: () => React.ReactElement; badge?: number; urgent?: boolean; divider?: boolean };

const studentNav: NavItem[] = [
  { id: "dashboard",    label: "Dashboard",           Icon: I.Home },
  { id: "emergency",    label: "I Don't Feel Safe",   Icon: I.Alert, urgent: true },
  { id: "report",       label: "Report an Incident",  Icon: I.File },
  { id: "tracking",     label: "My Reports",          Icon: I.List },
  { id: "consultation", label: "Request Consultation",Icon: I.Cal },
  { id: "rights",       label: "Know Your Rights",    Icon: I.Book },
  { id: "messages",     label: "Secure Messages",     Icon: I.Chat },
  { id: "notifications",label: "Notifications",       Icon: I.Bell },
];

// GAD Staff: triage, forward to director, scheduling & follow-ups only
// No case content, no messages, no analytics, no audit trail
const coordinatorNav: NavItem[] = [
  { id: "dashboard",       label: "Dashboard",          Icon: I.Home },
  { id: "staff-schedule",  label: "Scheduling",         Icon: I.Cal },
  { id: "staff-followups", label: "Follow-ups",         Icon: I.List },
  { id: "notifications",   label: "Notifications",      Icon: I.Bell },
];

// GAD Director — everything
const directorNav: NavItem[] = [
  { id: "dashboard",      label: "Dashboard",            Icon: I.Home },
  { id: "messages",       label: "Secure Messages",      Icon: I.Chat },
  { id: "notifications",  label: "Notifications",        Icon: I.Bell },
  { id: "analytics",      label: "Analytics",            Icon: I.Chart },
  { id: "programs",       label: "Programs & Awareness", Icon: I.Star },
  { id: "audit",          label: "Audit Trail",          Icon: I.Audit },
  { id: "admin-users",    label: "User Management",      Icon: I.Users },
  { id: "admin-settings", label: "System Settings",      Icon: I.Cog },
];

// System Admin — analytics & reports only
const adminNav: NavItem[] = [
  { id: "analytics",    label: "Analytics & Reports",  Icon: I.Chart },
  { id: "notifications",label: "Notifications",        Icon: I.Bell },
];

const NAV_BY_ROLE: Record<string, NavItem[]> = {
  student: studentNav,
  coordinator: coordinatorNav,
  director: directorNav,
  admin: adminNav,
};

const USER_INFO: Record<string, { name: string; sub: string; initial: string; badge?: string; badgeColor?: string }> = {
  student:     { name: "Maria Santos",  sub: "BSED · 3rd Year",    initial: "M" },
  coordinator: { name: "Carlo Dizon",   sub: "GAD Staff",          initial: "C",
                 badge: "Triage Only", badgeColor: "bg-amber-500" },
  director:    { name: "Dir. Lourdes Cruz", sub: "GAD Director",   initial: "D",
                 badge: "Full Access", badgeColor: "bg-violet-500" },
  admin:       { name: "System Admin",  sub: "IT Administrator",   initial: "SA",
                 badge: "Analytics Only", badgeColor: "bg-amber-500" },
};

const PORTAL_LABEL: Record<string, string> = {
  student:     "Student Portal",
  coordinator: "GAD Staff Portal",
  director:    "Director Portal",
  admin:       "Admin Portal",
};

export default function Sidebar({ displayName, role, currentView, onNavigate, onLogout }: Props) {
  const navItems = NAV_BY_ROLE[role] ?? [];
  const user = {...USER_INFO[role], name:displayName || "Signed-in user", sub: {student:"Student portal",coordinator:"GAD Staff",director:"GAD Director",admin:"Analytics access"}[role], initial:(displayName||"U")[0]};

  return (
    <aside className="w-60 max-md:w-full flex-shrink-0 bg-[#1E1B4B] flex flex-col h-full">
      {/* Logo */}
      <div className="px-5 py-6 border-b border-white/10">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-white/15 flex items-center justify-center flex-shrink-0">
            <I.Shield />
          </div>
          <div className="text-white min-w-0">
            <div className="font-bold text-sm leading-tight" style={{ fontFamily: "Outfit, sans-serif" }}>GAD SafeSpace</div>
            <div className="text-indigo-300 text-xs truncate">SDCC · Reporting System</div>
          </div>
        </div>
      </div>

      {/* Portal label */}
      <div className="px-5 py-3 flex items-center gap-2">
        <span className="text-xs font-semibold text-indigo-300 uppercase tracking-widest">
          {PORTAL_LABEL[role]}
        </span>
        {user.badge && (
          <span className={`${user.badgeColor} text-white text-xs font-bold px-2 py-0.5 rounded-full`}>
            {user.badge}
          </span>
        )}
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-3 pb-4 overflow-y-auto">
        <ul className="space-y-0.5">
          {navItems.map((item) => {
            const isActive = currentView === item.id;
            const { Icon } = item;
            return (
              <li key={item.id}>
                <button
                  onClick={() => onNavigate(item.id)}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-150 text-left ${
                    isActive
                      ? "bg-white/15 text-white"
                      : item.urgent
                      ? "text-rose-300 hover:bg-rose-500/20 hover:text-rose-200"
                      : "text-indigo-200 hover:bg-white/8 hover:text-white"
                  }`}
                >
                  <span className={`flex-shrink-0 ${isActive ? "text-white" : item.urgent ? "text-rose-400" : "text-indigo-400"}`}>
                    <Icon />
                  </span>
                  <span className="leading-tight flex-1">{item.label}</span>
                  {item.badge ? (
                    <span className="w-5 h-5 rounded-full bg-rose-500 text-white text-xs font-bold flex items-center justify-center flex-shrink-0">
                      {item.badge}
                    </span>
                  ) : isActive ? (
                    <span className="w-1.5 h-1.5 rounded-full bg-white flex-shrink-0" />
                  ) : null}
                </button>
              </li>
            );
          })}
        </ul>

        {/* Callouts */}
        {role === "coordinator" && (
          <div className="mt-6 mx-1 p-3 bg-amber-500/15 rounded-xl border border-amber-400/20">
            <p className="text-amber-300 text-xs font-semibold mb-1">📋 Staff Access</p>
            <p className="text-amber-200/60 text-xs leading-relaxed">
              Forward incoming reports to the GAD Director. No case content is visible to this role.
            </p>
          </div>
        )}

        {role === "director" && (
          <div className="mt-6 mx-1 p-3 bg-violet-500/20 rounded-xl border border-violet-400/20">
            <p className="text-violet-200 text-xs font-semibold mb-1">🛡️ Director Access</p>
            <p className="text-violet-200/60 text-xs">Full system access — all modules visible</p>
          </div>
        )}

        {role === "admin" && (
          <div className="mt-6 mx-1 p-3 bg-amber-500/15 rounded-xl border border-amber-400/20">
            <p className="text-amber-300 text-xs font-semibold mb-1">📊 Analytics & Reports</p>
            <p className="text-amber-200/60 text-xs">Your access is scoped to analytics and report generation only</p>
          </div>
        )}
      </nav>

      {/* User profile */}
      <div className="border-t border-white/10 p-4">
        <div className="flex items-center gap-3 mb-3">
          <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
            role === "director" ? "bg-violet-500" : role === "admin" ? "bg-amber-500" : "bg-indigo-500"
          }`}>
            <span className="text-white text-xs font-bold">{user.initial}</span>
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-white text-sm font-medium truncate">{user.name}</div>
            <div className="text-indigo-300 text-xs truncate">{user.sub}</div>
          </div>
        </div>
        <button
          onClick={onLogout}
          className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-indigo-300 hover:text-white hover:bg-white/10 text-xs font-medium transition-all"
        >
          <I.Logout />
          Sign out
        </button>
      </div>
    </aside>
  );
}
