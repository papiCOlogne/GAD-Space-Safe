import {supabase,supabaseUrl,publishableKey} from './supabase';
export async function apiFetch(path='',options:RequestInit={}){
 const {data:{session},error}=await supabase.auth.getSession();if(error||!session)throw new Error('Sign in to continue.');
 const response=await fetch(supabaseUrl+'/functions/v1/safespace-api'+path,{...options,headers:{...options.headers,apikey:publishableKey,Authorization:'Bearer '+session.access_token}});
 if(!response.ok){const d=await response.json().catch(()=>({error:'Request failed.'}));throw new Error(d.error||'Request failed.')}return response;
}
export async function api(body?:unknown){return (await apiFetch('',body?{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}:{})).json()}
export async function upload(report:string,file:File){const data=new FormData();data.append('report',report);data.append('file',file);return (await apiFetch('',{method:'POST',body:data})).json()}
export async function downloadEvidence(id:string,name:string){const r=await apiFetch('?file='+encodeURIComponent(id));const blob=await r.blob();const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)}
