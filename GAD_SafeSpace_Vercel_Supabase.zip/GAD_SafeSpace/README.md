# GAD SafeSpace — Vercel + Supabase edition

This edition removes ChatGPT Sites authentication and Cloudflare-specific runtime dependencies. The React website is configured for Vercel. Authentication, PostgreSQL records, and private evidence storage use the connected SDCC GAD Supabase project.

## Current state

- Supabase project: hamxrxuatenyqiqbxtrx (SDCC GAD).
- Tables and restricted server-only access are deployed.
- The safespace-api Edge Function is deployed. It validates the signed-in user with auth.getUser on every request and checks roles from the database.
- Evidence bucket safespace-evidence is private. Files are served only through the authenticated API.
- The frontend builds successfully and includes email/password sign-in, signup, and password reset.
- Vercel deployment, production auth redirects, the first director assignment, and end-to-end testing with real accounts are still pending.
- Existing ChatGPT Sites records have NOT been copied. The original site has NOT been removed.

## Run and deploy the frontend

Use Node.js 22 or newer. Run `npm ci`, then `npm run dev` for local development or `npm run build` for production output in dist/.

Import this directory into Vercel as a Vite project. vercel.json configures the build, output folder, SPA routes, and response headers. The Supabase URL and publishable client key in src/supabase.ts are intentionally public; no service-role key belongs in this website or its environment.

Once the production URL exists, configure that exact URL as the Supabase Auth Site URL and allow the root and /?reset=1 redirect destinations. Email confirmation must stay enabled. Verify confirmation and reset delivery; configure an appropriate SMTP provider before inviting users beyond the project's permitted test recipients.

## First director account

No public signup becomes a director automatically. Create and verify the intended director's account first. An authorized project administrator must then assign its verified email the director role in safespace_members and set safespace_config's owner value to that same email. Do not use an arbitrary first-user claim on a publicly accessible site.

All new accounts receive student access. The director can assign other roles from User Management after the owner has been provisioned. No sample accounts or default passwords are included.

## Backend maintenance

supabase/schema.sql records the applied schema for review; do not rerun it against the already configured project. The Edge Function source is under supabase/functions/safespace-api. verify_jwt is false at the gateway because the function performs its own auth.getUser validation; this does NOT allow unauthenticated requests.

Only service_role can access the application tables or invoke the write RPC. That credential is supplied by the Supabase Edge Function environment and never sent to the browser. The write RPC uses invoker permissions, commits report/status/evidence changes with audit entries, and serializes attachment limits and appointment confirmation checks.

## Migration completion

Before removing the old ChatGPT-hosted version: inventory existing records and attachments; export them through an authorized server path; map old account identities to verified Supabase users; import and check counts, ownership, attachments and timestamps; verify representative accounts on the new site; then retire the old hosting. An empty target database is not evidence that the old database is empty.

## Limits

No automatic email/SMS case notifications or emergency dispatch are implemented. Account verification and password reset emails are handled by Supabase Auth. Name omission is not anonymous reporting: account linkage remains for access control and audit. Suggested priority is a simple rule, not a professional safety assessment.
