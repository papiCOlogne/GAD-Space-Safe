import {createClient} from 'npm:@supabase/supabase-js@2.118.0';
import {z} from 'npm:zod@3.25.76';
const cors={'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'authorization, apikey, content-type, x-client-info','Access-Control-Allow-Methods':'GET, POST, OPTIONS','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'};
const roles=['student','coordinator','director','admin'] as const;
const statuses=['Submitted','Forwarded','Under Review','In Progress','Resolved','Closed'] as const;
const reportSchema=z.object({concern:z.enum(['sexual-harassment','bullying','gbv','discrimination','stalking','inappropriate-conduct','other']),incidentDate:z.string().regex(/^\d{4}-\d{2}-\d{2}$/),incidentTime:z.string().max(10),location:z.string().min(1).max(200),description:z.string().trim().min(20).max(12000),reportedName:z.string().max(200),reportedRole:z.string().max(100),witnesses:z.string().max(2000),repeated:z.boolean(),confidentiality:z.enum(['identified','confidential','anonymous','advice']),contact:z.enum(['email','phone','message','none'])});
const json=(d:unknown,status=200)=>Response.json(d,{status,headers:cors});
function fail(message:string,status=400):never{throw Object.assign(new Error(message),{status})}
function allow(role:string,list:string[]){if(!list.includes(role))fail('You do not have permission for this action.',403)}
function unpack(r:any){return {id:r.id,created:r.created,parent:r.parent,...r.data}}
const uuid=()=>crypto.randomUUID();
export async function handler(req:Request){
 if(req.method==='OPTIONS')return new Response('ok',{headers:cors});
 try{
  if(!['GET','POST'].includes(req.method))fail('Method not allowed.',405);
  const token=req.headers.get('Authorization')?.match(/^Bearer (.+)$/i)?.[1];if(!token)fail('Sign in to continue.',401);
  const client=createClient(Deno.env.get('SUPABASE_URL')!,Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,{auth:{persistSession:false,autoRefreshToken:false}});
  const {data:auth,error:authError}=await client.auth.getUser(token);
  if(authError||!auth.user?.email||!auth.user.email_confirmed_at)fail('Sign in with a verified email account.',401);
  const user={userId:auth.user.id,email:auth.user.email.toLowerCase(),name:auth.user.user_metadata?.full_name||auth.user.email,role:'student',isOwner:false};
  async function checked(query:any){const {data,error}=await query;if(error){console.error('Database operation failed',error.code);if(error.message?.includes('STALE_STATUS'))fail('This report changed. Refresh and try again.',409);if(error.message?.includes('TIME_BOOKED'))fail('That appointment time is already booked.',409);if(error.message?.includes('Maximum five'))fail('Maximum five attachments per report.');fail('The request could not be saved. Please try again.',500)}return data;}
  await checked(client.from('safespace_members').upsert({email:user.email,role:'student',active:1},{onConflict:'email',ignoreDuplicates:true}));
  const member=await checked(client.from('safespace_members').select('*').eq('email',user.email).single());if(!member.active)fail('This account has been disabled.',403);user.role=member.role;
  const config=await checked(client.from('safespace_config').select('*'));const settings=config.find((x:any)=>x.key==='settings')?.value||{office:'SDCC GAD Office',contact:'',hours:''};const owner=config.find((x:any)=>x.key==='owner')?.value;user.isOwner=owner===user.email;
  async function list(kind:string,filter?:{key:string,value:string}){const out:any[]=[];for(let page=0;page<100;page++){let query=client.from('safespace_records').select('*').eq('kind',kind).order('created',{ascending:false}).order('id').range(page*1000,(page+1)*1000-1);if(filter)query=query.eq(filter.key,filter.value);const batch=await checked(query);out.push(...batch);if(batch.length<1000)return out;}fail('Too many records to display. Contact the administrator.',413)}
  async function getReport(key:string,content=true){allow(user.role,content?['student','director']:['student','director','coordinator']);const row=await checked(client.from('safespace_records').select('*').eq('kind','report').eq('id',key).maybeSingle());if(!row||(user.role==='student'&&row.owner!==user.userId))fail('Report not found.',404);return row;}
  async function write(operation:string,kind:string,key:string,data:any,parent='',ownerId=user.userId,expected:string|null=null){await checked(client.rpc('safespace_write',{p_operation:operation,p_actor:user.email,p_id:key,p_owner:ownerId,p_kind:kind,p_parent:parent,p_data:data,p_expected:expected}));}
  async function audit(action:string,reference=''){await checked(client.from('safespace_records').insert({id:uuid(),kind:'audit',owner:user.email,data:{actor:user.email,action,reference}}));}
  const url=new URL(req.url);
  if(req.method==='GET'){
   const file=url.searchParams.get('file');if(file){const row=await checked(client.from('safespace_records').select('*').eq('kind','attachment').eq('id',file).maybeSingle());if(!row)fail('File not found.',404);await getReport(row.parent);const {data,error}=await client.storage.from('safespace-evidence').download(file);if(error||!data)fail('File not found.',404);return new Response(data,{headers:{...cors,'Content-Type':row.data.type,'Content-Disposition':`attachment; filename*=UTF-8''${encodeURIComponent(row.data.name)}`}})}
   const parent=url.searchParams.get('attachments');if(parent){await getReport(parent);return json((await list('attachment',{key:'parent',value:parent})).map(unpack))}
   const all=await list('report',user.role==='student'?{key:'owner',value:user.userId}:undefined);
   const stats=Object.fromEntries(statuses.map(s=>[s,all.filter(r=>r.data.status===s).length]));const categories:Record<string,number>={};for(const r of all)categories[r.data.concern]=(categories[r.data.concern]||0)+1;
   const reports=user.role==='admin'?[]:all.map(r=>user.role==='coordinator'?{id:r.id,created:r.created,status:r.data.status,risk:r.data.risk}:unpack(r));
   const ids=new Set(all.map(r=>r.id));
   const messages=['student','director'].includes(user.role)?(await list('message')).filter(r=>ids.has(r.parent)).map(unpack).reverse():[];
   const consultations=user.role==='admin'?[]:(await list('consultation',user.role==='student'?{key:'owner',value:user.userId}:undefined)).map(unpack);
   const events=user.role==='admin'?[]:(await list('event')).filter(r=>ids.has(r.parent)).map(unpack);
   return json({user,reports,stats,categories: ['director','admin'].includes(user.role)?categories:{},messages,consultations,events,settings,programs:(await list('program')).map(unpack),users:user.role==='director'?await checked(client.from('safespace_members').select('*').order('email')):[],audit:user.role==='director'?(await checked(client.from('safespace_records').select('*').eq('kind','audit').order('created',{ascending:false}).limit(200))).map(unpack):[]});
  }
  if(req.headers.get('content-type')?.includes('multipart/form-data')){
   const data=await req.formData();const parent=String(data.get('report')||'');await getReport(parent);const file=data.get('file');if(!(file instanceof File))fail('Choose a file.');
   if(!file.size||file.size>10485760)fail('Files must be between 1 byte and 10 MB.');if(!['image/png','image/jpeg','application/pdf','audio/mpeg','video/mp4'].includes(file.type))fail('Unsupported file format.');
   const key=uuid();const {error}=await client.storage.from('safespace-evidence').upload(key,file,{contentType:file.type,upsert:false});if(error)fail('Evidence upload failed. Please retry.',500);
   try{await write('attachment','attachment',key,{name:file.name.slice(0,160),type:file.type,size:file.size},parent)}catch(e){await client.storage.from('safespace-evidence').remove([key]);throw e}return json({id:key});
  }
  let b:any;try{b=await req.json()}catch{fail('Invalid JSON request.')}
  if(b.action==='report'){
   allow(user.role,['student','director']);const form=reportSchema.parse(b.data);const today=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Manila'}).format(new Date());if(form.incidentDate>today||isNaN(Date.parse(form.incidentDate)))fail('Enter a valid incident date, no later than today.');
   const key='GAD-'+new Date().getFullYear()+'-'+uuid().replaceAll('-','').slice(0,16).toUpperCase();const authority=['faculty','admin'].includes(form.reportedRole);const risk=['gbv','sexual-harassment'].includes(form.concern)||(authority&&form.repeated)?'High':authority||form.repeated?'Moderate':'Low';
   await write('create','report',key,{...form,status:'Submitted',risk,reporter:form.confidentiality==='anonymous'?'Identity withheld':user.name,contactEmail:form.confidentiality==='anonymous'?'':user.email});return json({id:key});
  }
  if(b.action==='status'){
   allow(user.role,['director','coordinator']);const r=await getReport(z.string().parse(b.id),false);const status=z.enum(statuses).parse(b.status);if(user.role==='coordinator'&&(r.data.status!=='Submitted'||status!=='Forwarded'))fail('Staff may only forward new reports.',403);await write('status','report',r.id,{status},'',r.owner,z.string().parse(b.previousStatus));
  }else if(b.action==='message'){
   const r=await getReport(z.string().parse(b.id));await write('create','message',uuid(),{text:z.string().trim().min(1).max(5000).parse(b.text),sender:user.role==='director'?'GAD Director':'Reporter'},r.id);
  }else if(b.action==='consultation'){
   allow(user.role,['student','director']);const data=z.object({date:z.string().datetime(),mode:z.enum(['In person','Online','Phone']),note:z.string().max(1000)}).parse(b.data);if(Date.parse(data.date)<Date.now())fail('Choose a future appointment time.');await write('create','consultation',uuid(),{...data,name:user.name,email:user.email,status:'Requested'});
  }else if(b.action==='schedule'){
   allow(user.role,['coordinator','director']);await write('schedule','consultation',z.string().parse(b.id),{status:z.enum(['Confirmed','Completed','Cancelled']).parse(b.status)});
  }else if(b.action==='user'){
   allow(user.role,['director']);const data=z.object({email:z.string().email().transform(s=>s.toLowerCase()),role:z.enum(roles),active:z.number().int().min(0).max(1)}).parse(b.data);if(data.email===owner||data.email===user.email)fail('You cannot change your own or the owner account.');await checked(client.from('safespace_members').upsert(data));await audit('Account access updated',data.email);
  }else if(b.action==='program'){
   allow(user.role,['director']);await write('create','program',uuid(),z.object({title:z.string().trim().min(1).max(150),date:z.string().min(1).max(40),description:z.string().min(1).max(3000)}).parse(b.data));
  }else if(b.action==='settings'){
   allow(user.role,['director']);const data=z.object({office:z.string().min(1).max(150),contact:z.string().max(150),hours:z.string().max(200)}).parse(b.data);await checked(client.from('safespace_config').upsert({key:'settings',value:data}));await audit('Office settings updated');
  }else fail('Unknown action.');
  return json({ok:true});
 }catch(e:any){return json({error:e instanceof z.ZodError?e.issues.map(i=>i.message).join('; '):e.status?e.message:'The request could not be completed.'},e.status||(e instanceof z.ZodError?400:500))}
}
Deno.serve(handler);
