create table public.safespace_members (
 email text primary key check(email=lower(email)),
 role text not null default 'student' check(role in ('student','coordinator','director','admin')),
 active integer not null default 1 check(active in (0,1))
);
create table public.safespace_records (
 id text primary key,
 kind text not null check(kind in ('report','message','event','audit','consultation','program','attachment')),
 owner text not null,
 parent text not null default '',
 data jsonb not null,
 created timestamptz not null default now()
);
create index safespace_records_kind_owner_created on public.safespace_records(kind,owner,created desc);
create index safespace_records_parent_kind on public.safespace_records(parent,kind);
create table public.safespace_config(key text primary key, value jsonb not null);
alter table public.safespace_members enable row level security;
alter table public.safespace_records enable row level security;
alter table public.safespace_config enable row level security;
revoke all on public.safespace_members,public.safespace_records,public.safespace_config from anon,authenticated;
grant all on public.safespace_members,public.safespace_records,public.safespace_config to service_role;
create policy backend_only on public.safespace_members to service_role using(true) with check(true);
create policy backend_only on public.safespace_records to service_role using(true) with check(true);
create policy backend_only on public.safespace_config to service_role using(true) with check(true);

-- Invoker RPC callable only by the authenticated server component.
-- Core record changes and their audit entries are committed atomically.
create function public.safespace_write(p_operation text,p_actor text,p_id text,p_owner text,p_kind text,p_parent text,p_data jsonb,p_expected text default null)
returns void language plpgsql security invoker set search_path='' as $$
declare existing public.safespace_records; count_files integer;
begin
 if p_operation='status' then
  select * into existing from public.safespace_records where id=p_id and kind='report' for update;
  if not found then raise exception 'Report not found'; end if;
  if existing.data->>'status' is distinct from p_expected then raise exception 'STALE_STATUS'; end if;
  update public.safespace_records set data=data||p_data where id=p_id;
  insert into public.safespace_records(id,kind,owner,parent,data) values(gen_random_uuid()::text,'event',existing.owner,p_id,jsonb_build_object('text','Status changed to '||(p_data->>'status'),'status',p_data->>'status'));
 elsif p_operation='attachment' then
  perform 1 from public.safespace_records where id=p_parent and kind='report' for update;
  if not found then raise exception 'Report not found'; end if;
  select count(*) into count_files from public.safespace_records where kind='attachment' and parent=p_parent;
  if count_files>=5 then raise exception 'Maximum five attachments per report'; end if;
  insert into public.safespace_records(id,kind,owner,parent,data) values(p_id,p_kind,p_owner,p_parent,p_data);
 elsif p_operation='create' then
  insert into public.safespace_records(id,kind,owner,parent,data) values(p_id,p_kind,p_owner,p_parent,p_data);
  if p_kind='report' then
   insert into public.safespace_records(id,kind,owner,parent,data) values(gen_random_uuid()::text,'event',p_owner,p_id,'{"text":"Report received","status":"Submitted"}');
  end if;
 elsif p_operation='schedule' then
  -- Serialize booking confirmations to avoid double bookings.
  perform pg_advisory_xact_lock(497211);
  select * into existing from public.safespace_records where id=p_id and kind='consultation' for update;
  if not found then raise exception 'Appointment not found'; end if;
  if p_data->>'status'='Confirmed' and exists(select 1 from public.safespace_records where kind='consultation' and id<>p_id and data->>'status'='Confirmed' and data->>'date'=existing.data->>'date') then raise exception 'TIME_BOOKED'; end if;
  update public.safespace_records set data=data||p_data where id=p_id;
 else raise exception 'Unknown operation'; end if;
 insert into public.safespace_records(id,kind,owner,data) values(gen_random_uuid()::text,'audit',p_actor,jsonb_build_object('actor',p_actor,'action',p_operation||' '||p_kind,'reference',p_id));
end $$;
revoke all on function public.safespace_write(text,text,text,text,text,text,jsonb,text) from public,anon,authenticated;
grant execute on function public.safespace_write(text,text,text,text,text,text,jsonb,text) to service_role;
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types) values('safespace-evidence','safespace-evidence',false,10485760,array['image/png','image/jpeg','application/pdf','audio/mpeg','video/mp4']);
